//
//  DetailViewController.h
//  CoreDataFavourites
//
//  Created by Cenny Davidsson on 2014-10-02.
//  Copyright (c) 2014 Linköpings University. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Link;

@interface DetailViewController : UIViewController

@property (strong, nonatomic) Link *link;


@end

