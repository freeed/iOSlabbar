//
//  AppDelegate.h
//  DiceRoll
//
//  Created by Alek Åström on 2012-01-19.
//  Copyright (c) 2012 Linköping University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
