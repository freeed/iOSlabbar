//
//  ViewController.h
//  Laboration5
//
//  Created by Fredrik Sjöberg on 08/12/14.
//  Copyright (c) 2014 Fredrik Sjöberg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

