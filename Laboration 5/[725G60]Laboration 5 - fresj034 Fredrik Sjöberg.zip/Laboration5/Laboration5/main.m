//
//  main.m
//  Laboration5
//
//  Created by Fredrik Sjöberg on 08/12/14.
//  Copyright (c) 2014 Fredrik Sjöberg. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
