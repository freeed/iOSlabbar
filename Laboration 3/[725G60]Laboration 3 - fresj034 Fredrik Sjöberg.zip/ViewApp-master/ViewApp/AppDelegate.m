//
//  AppDelegate.m
//  ViewApp
//
//  Created by Alek Åström on 2012-02-01.
//  Copyright (c) 2012 Linköping University. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}

@end
