//
//  main.m
//  ViewApp
//
//  Created by Alek Åström on 2012-02-01.
//  Copyright (c) 2012 Linköping University. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
