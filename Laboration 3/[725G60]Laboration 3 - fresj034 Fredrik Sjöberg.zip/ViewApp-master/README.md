ViewApp
=======
I det färdiga programmet ska du öva på att använda Interface Builder för att bygga gränssnitt. Utöver Interface Builder kommer du också testa att bygga ett enkelt grafiskt gränssnitt med enbart kod. Du kommer även att få testa på att använda dig av delegater. Det finns en del given kod men en hel del ska du komplettera med själv.

Innan du börjar skriva någon kod eller ändrar på någonting, läs noga igenom alla kommentarer i koden. Exakt vad som ska göras finns väl kommenterat där. Uppgiften är uppdelad i tre olika delar. Börja med FirstViewController och fortsätt i stigande ordning.
